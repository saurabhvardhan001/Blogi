package com.blogi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.blogi.entity.BlogPost;

public interface BlogRepository extends JpaRepository<BlogPost, Long> {
}
