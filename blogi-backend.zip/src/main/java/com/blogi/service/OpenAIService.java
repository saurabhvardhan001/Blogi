package com.blogi.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.*;

@Service
public class OpenAIService {

    private final WebClient webClient;

    @Value("${azure.openai.endpoint}")
    private String endpoint;

    @Value("${azure.openai.deployment}")
    private String deployment;

    @Value("${azure.openai.api-version}")
    private String apiVersion;

    public OpenAIService(@Value("${azure.openai.key}") String apiKey) {
        this.webClient = WebClient.builder()
                .defaultHeader("api-key", apiKey)
                .build();
    }

    public String generateBlog(String prompt) {
        String url = String.format("%s/openai/deployments/%s/chat/completions?api-version=%s", endpoint, deployment, apiVersion);

        Map<String, Object> body = new HashMap<>();
        body.put("messages", List.of(
                Map.of("role", "system", "content", "You are Blogi, an SEO-focused blog writer. Use markdown headings, subheadings, bullet lists, and include an engaging introduction and conclusion."),
                Map.of("role", "user", "content", prompt)
        ));
        body.put("temperature", 0.7);
        body.put("max_tokens", 1200);
        body.put("top_p", 0.95);
        body.put("stream", false);

        Map<String, Object> response = this.webClient.post()
                .uri(url)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .onErrorResume(e -> Mono.just(Map.of()))
                .block();

        if (response == null) return "";
        try {
            List choices = (List) response.get("choices");
            Map first = (Map) choices.get(0);
            Map message = (Map) first.get("message");
            return (String) message.get("content");
        } catch (Exception ex) {
            return "";
        }
    }
}
