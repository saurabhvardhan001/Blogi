package com.blogi.service;

import com.blogi.dto.GenerateRequest;
import com.blogi.entity.BlogPost;
import com.blogi.repository.BlogRepository;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class BlogService {
    private final OpenAIService openAIService;
    private final SeoService seoService;
    private final PlagiarismService plagiarismService;
    private final BlogRepository blogRepository;

    public BlogService(OpenAIService openAIService, SeoService seoService, PlagiarismService plagiarismService, BlogRepository blogRepository) {
        this.openAIService = openAIService; this.seoService = seoService; this.plagiarismService = plagiarismService; this.blogRepository = blogRepository;
    }

    public BlogPost generateAndSave(GenerateRequest req, String username) {
        String prompt = buildPrompt(req);
        String content = openAIService.generateBlog(prompt);
        if (content == null || content.isBlank()) content = "# Draft could not be generated. Please tweak your prompt.";

        BlogPost post = new BlogPost();
        String title = deriveTitle(content, req.getTopic());
        post.setTitle(title);
        post.setContent(content);
        post.setMetaTitle(title.length() > 60 ? title.substring(0,57)+"..." : title);
        post.setMetaDescription(seoService.metaDescription(content));
        post.setKeywords(req.getKeywords() == null ? List.of() : req.getKeywords());
        post.setReadabilityScore(seoService.readabilityScore(content));
        post.setSeoScore(seoService.seoScore(title, post.getKeywords(), content));
        post.setPlagiarismScore(plagiarismService.score(content));
        return blogRepository.save(post);
    }

    private String deriveTitle(String content, String fallback) {
        for (String line : content.split("
")) {
            String l = line.trim();
            if (l.startsWith("# ")) return l.substring(2).trim();
        }
        return fallback;
    }

    private String buildPrompt(GenerateRequest req) {
        StringBuilder sb = new StringBuilder();
        sb.append("Topic: ").append(req.getTopic()).append("
");
        if (req.getKeywords() != null && !req.getKeywords().isEmpty()) sb.append("Keywords: ").append(String.join(", ", req.getKeywords())).append("
");
        if (req.getTone() != null) sb.append("Tone: ").append(req.getTone()).append("
");
        if (req.getTargetAudience() != null) sb.append("Audience: ").append(req.getTargetAudience()).append("
");
        if (req.getLength() > 0) sb.append("Target length: ").append(req.getLength()).append(" words
");
        sb.append("
Please produce a high-quality, SEO-optimized blog post in Markdown with:
- Clear H1 title
- Table of contents if long
- H2/H3 sections
- Bulleted lists and examples
- Meta title and description suggestions at the end under a heading 'SEO Meta'
- Call-to-action in the conclusion
");
        return sb.toString();
    }
}
