import React, { useState } from 'react'
import api from '../services/api'
import { Container, TextField, Button, Paper, Typography, Stack, Chip } from '@mui/material'

export default function Editor(){
  const [topic, setTopic] = useState('')
  const [keywords, setKeywords] = useState('')
  const [tone, setTone] = useState('Formal')
  const [aud, setAud] = useState('Beginners')
  const [length, setLength] = useState(800)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)

  const submit = async () => {
    setLoading(true)
    try {
      const { data } = await api.post('/api/blog/generate', {
        topic,
        keywords: keywords.split(',').map(k=>k.trim()).filter(Boolean),
        tone, targetAudience: aud, length: Number(length)
      })
      setResult(data)
    } catch (e) { alert('Generation failed') } finally { setLoading(false) }
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h5" gutterBottom>AI Blog Generator</Typography>
        <Stack spacing={2}>
          <TextField label="Topic" value={topic} onChange={e=>setTopic(e.target.value)} />
          <TextField label="Keywords (comma separated)" value={keywords} onChange={e=>setKeywords(e.target.value)} />
          <Stack direction="row" spacing={2}>
            <TextField label="Tone" value={tone} onChange={e=>setTone(e.target.value)} />
            <TextField label="Audience" value={aud} onChange={e=>setAud(e.target.value)} />
            <TextField label="Length (words)" type="number" value={length} onChange={e=>setLength(e.target.value)} />
          </Stack>
          <Button variant="contained" onClick={submit} disabled={loading}>{loading ? 'Generating...' : 'Generate'}</Button>
        </Stack>
      </Paper>

      {result && (
        <Paper sx={{ p:3, mt:3 }}>
          <Typography variant="h6">{result.metaTitle || result.title}</Typography>
          <Typography variant="body2" sx={{mb:1}} color="text.secondary">{result.metaDescription}</Typography>
          <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
            {result.keywords && result.keywords.map((k,i)=> <Chip key={i} label={k} />)}
          </Stack>
          <div style={{whiteSpace:'pre-wrap'}}>{result.content}</div>
          <Typography sx={{mt:2}} color="text.secondary">Readability: {result.readabilityScore} | SEO: {result.seoScore} | Plagiarism: {result.plagiarismScore}</Typography>
        </Paper>
      )}
    </Container>
  )
}
