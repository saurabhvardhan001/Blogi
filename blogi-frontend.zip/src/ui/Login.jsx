import React, { useState } from 'react'
import api from '../services/api'
import { Container, TextField, Button, Paper, Typography, Stack } from '@mui/material'
import { useNavigate } from 'react-router-dom'

export default function Login(){
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const submit = async () => {
    try {
      const { data } = await api.post('/api/auth/login', { username, password })
      localStorage.setItem('token', data.token)
      navigate('/editor')
    } catch (e) { setError('Invalid credentials') }
  }

  return (
    <Container maxWidth="sm" sx={{ mt: 8 }}>
      <Paper sx={{ p: 4 }}>
        <Typography variant="h5" gutterBottom>Login</Typography>
        <Stack spacing={2}>
          <TextField label="Username" value={username} onChange={e=>setUsername(e.target.value)} />
          <TextField label="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
          {error && <Typography color="error">{error}</Typography>}
          <Button variant="contained" onClick={submit}>Login</Button>
        </Stack>
      </Paper>
    </Container>
  )
}
