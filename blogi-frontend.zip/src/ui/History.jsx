import React, { useEffect, useState } from 'react'
import api from '../services/api'
import { Container, Paper, Typography, List, ListItem, ListItemText } from '@mui/material'

export default function History(){
  const [items, setItems] = useState([])
  useEffect(()=>{ (async ()=>{ const { data } = await api.get('/api/blog'); setItems(data) })() },[])
  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper sx={{ p: 3 }}>
        <Typography variant="h5" gutterBottom>Generated Blogs</Typography>
        <List>
          {items.map(b => (
            <ListItem key={b.id}>
              <ListItemText primary={b.title} secondary={b.metaDescription} />
            </ListItem>
          ))}
        </List>
      </Paper>
    </Container>
  )
}
